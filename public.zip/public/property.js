const params = new URLSearchParams(window.location.search);
const id = parseInt(params.get("id"));

const property = properties.find(p => p.id === id);

if (!property) {
  document.body.innerHTML = "<h2>Property not found</h2>";
} else {

  document.getElementById("propertyTitle").innerText = property.title;
  document.getElementById("propertyPrice").innerText =
    "$" + property.price.toLocaleString();

  document.getElementById("propertyDescription").innerText =
    property.description;

  document.getElementById("propertyLocation").innerText =
    property.location;

  document.getElementById("propertyImage").style.backgroundImage =
    `url(${property.image})`;
}